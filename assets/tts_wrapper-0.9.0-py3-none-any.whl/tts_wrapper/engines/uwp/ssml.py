from ...ssml import BaseSSMLRoot, SSMLNode

UWPSSML = BaseSSMLRoot