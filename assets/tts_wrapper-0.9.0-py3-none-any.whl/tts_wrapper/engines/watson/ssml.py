from tts_wrapper.ssml.ssml_node import SSMLNode
from ...ssml import BaseSSMLRoot

WatsonSSML = BaseSSMLRoot
