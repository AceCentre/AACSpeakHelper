from .client import WatsonClient
from .ssml import WatsonSSML
from .watson import WatsonTTS
