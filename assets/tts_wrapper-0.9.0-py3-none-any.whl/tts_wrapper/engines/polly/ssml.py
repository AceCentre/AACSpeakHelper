from ...ssml import BaseSSMLRoot, SSMLNode

PollySSML = BaseSSMLRoot
